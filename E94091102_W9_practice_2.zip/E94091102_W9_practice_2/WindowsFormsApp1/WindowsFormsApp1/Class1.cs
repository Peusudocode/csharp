﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Media;
using System.IO;

namespace WindowsFormsApp1
{
    class MusicPlayer : SoundPlayer
    {
        public bool Loop = false;
        public string[] Playlist;

        // public string[] SelectWavFiles(string i)

        // public void Play()

        // public void SetMusicLocation(string path)

        // public void Saveplaylist()

        // public string[] LoadPlaylist()
    }


}
