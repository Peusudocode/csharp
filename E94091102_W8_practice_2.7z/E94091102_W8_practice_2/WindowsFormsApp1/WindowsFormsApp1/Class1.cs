﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    class Character
    {
        public int numA;
        public int numB;
        public int numC;
        public int numD;
        public System.Drawing.Color color;
    }
}
